package com.teambackend.dto;

import lombok.Data;

@Data
public class RegionDTO {
    private String DoNm;
    private String SigunguNm;
}
