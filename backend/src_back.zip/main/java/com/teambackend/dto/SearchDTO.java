package com.teambackend.dto;

import lombok.Data;

@Data
public class SearchDTO {
    private String FacltNm;
}
