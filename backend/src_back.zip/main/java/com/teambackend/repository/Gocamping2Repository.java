package com.teambackend.repository;

import com.teambackend.domain.Gocamping;
import com.teambackend.domain.Gocamping2;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Gocamping2Repository extends JpaRepository<Gocamping2, Long> {

}
