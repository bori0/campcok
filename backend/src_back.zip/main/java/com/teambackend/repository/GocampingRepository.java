package com.teambackend.repository;

import com.teambackend.domain.Gocamping;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GocampingRepository extends JpaRepository<Gocamping, Long> {

}
